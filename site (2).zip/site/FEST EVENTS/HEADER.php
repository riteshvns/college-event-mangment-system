<HTML>
<HEAD>
<TITLE>HEADER</TITLE>
<STYLE>

body:hover .c{
transform:rotate(1080deg);
transition:3s;
overflow:hidden;
}
.a{
position:relative;
height:8%;
width:100%;
padding-left:0px;
padding-right:0px;
background-color:white;

}

.b{
position:absolute;
top:0%;
left:1.2%;
font-size:40px;
font-family:Cooper;

}
.lg{
float:left;
color:linear-gradient(to right,orange,green,pink,green,blue,indigo,voilet);

}
.lg:hover{

cursor:pointer;
}
.lg{
font-size:45px;
background:-webkit-linear-gradient(orange, green, pink, green, blue, indigo, violet);
-webkit-background-clip:text;
-webkit-text-fill-color:transparent;
}
.c{
float:left;
background-color:transparent;
}

.blinking{
float:left;

animation:blinkingText 3s infinite;
}
@keyframes blinkingText{
0%{color:black;}
10%{color:peach;}
20%{color:seagreen;}
30%{color:teal;}
40%{color:grey;}
60%{color:Peru;}
80%{color:blue;}
90%{color:mustard;}
100%{color:DarkOrange;}

}
.blinking1{
float:left;

animation:blinkingText 3s infinite;
}
@keyframes blinking1Text{

0%{color:DarkOrange;}
10%{color:black;}
20%{color:peach;}
30%{color:seagreen;}
40%{color:teal;}
60%{color:grey;}
80%{color:Peru;}
90%{color:blue;}
100%{color:mustard;}

}
.blinking2{
float:left;

animation:blinkingText 3s infinite;
}
@keyframes blinking2Text{
0%{color:mustard;}
10%{color:DarkOrange;}
20%{color:black;}
30%{color:peach;}
40%{color:seagreen;}
60%{color:teal;}
80%{color:grey;}
90%{color:Peru;}
100%{color:blue;}

}
.aa{
position:relative;
float:right;
margin-top:1%;
margin-left:.5%;
font-size:17px;
font-weight:bold;
padding:5px;
COLOR: OliveDrab;
}
.aa:hover{
background-color:OliveDrab;
color:white;
padding:5px;
cursor:pointer;
border-radius:10px;

}

.aa2{
position:relative;
float:right;
margin-top:1%;
margin-left:.5%;
font-size:17px;
font-weight:bold;
padding:5px;
COLOR: OliveDrab;
}
.aa2:hover{
background-color:OliveDrab;
color:white;
padding:5px;
cursor:pointer;
border-radius:10px;

}


.h{
color:black;
width:100%;
size:10px;
}

A{

	COLOR: OliveDrab;
	text-decoration: NONE;

}

.aa:HOVER A{
	COLOR: WHITE;
	background-color: OliveDrab;

}

.aa2:HOVER A{
	COLOR: WHITE;
	background-color: OliveDrab;

}
  .ind{

  	display: inline-block;
  	height: 38px;
  	width: 38px;
  }

</STYLE>
</HEAD>
<BODY>

<hr class="h">
<div class="a">
<div class="b">






	<!-- <div class="c"><div class="lg"><img src="index.png" height="40" width="40" class="ind"></div></div> -->
<div  class="blinking">S</div>
<div  class="blinking">M</div>
<div  class="blinking1">S</div>
 


<div class="c"><div class="">E</div></div>
<div  class="blinking">V</div>
<div  class="blinking1">E</div>
<div class="c"><div  class="">N</div></div>
<div  class="blinking2">T</div>
<div  class="blinking2">S</div>
</div>




<div align="right" class="aa"><A HREF="STU_LOGIN.php">STUDENT LOGIN</A></div>
<div align="right" class="aa"><A HREF="LOGIN.php">ADMIN LOGIN</A></div>
<div align="right" class="aa2"><A HREF="REG FORM.php">NEW REGISTER</A></div>
<div align="right" class="aa2"><A HREF="HOME.php">HOME</A></div>
</div>
<hr class="h">

</BODY>
</HTML>