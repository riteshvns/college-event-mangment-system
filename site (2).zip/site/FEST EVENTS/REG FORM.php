<?php 
include 'connect.php';

if(isset($_POST['submit'])){

$photo=$_FILES['photo']['name'];
$photo_tmp=$_FILES['photo']['tmp_name'];
move_uploaded_file($photo_tmp,"upload_images/$photo");

$stu_name = $_POST['stu_name'];
$roll_no = $_POST['roll_no'];
$course = $_POST['course'];
$year = $_POST['year'];
$dob = $_POST['dob'];
$mob_no = $_POST['mob_no'];
$mail_id = $_POST['mail_id'];
$address = $_POST['address'];
$password = $_POST['password'];

 $qry="SELECT * FROM `reg_form` WHERE  `mail_id`='$mail_id' ";
      $result = mysqli_query($con,$qry);
      $row = mysqli_num_rows($result);

      if($row >= 1)  
      {
        echo '<script type="text/javascript"> alert("Already Registered!!")</script>';
    echo '<script type="text/javascript"> alert("Kindly Change Mail id!!")</script>';
        echo "<script> window.open('REG FORM.php','_self')</script>";
      }
else{

$query = mysqli_query($con,"INSERT INTO `reg_form`(`stu_name`, `roll_no`, `course`, `year`, `dob`, `mob_no`, `mail_id`, `photo`, `address`, `password`) VALUES ('$stu_name', '$roll_no', '$course', '$year', '$dob', '$mob_no','$mail_id', '$photo', '$address', '$password')");
if($query)
{
	echo"<script>alert('form registered successfully')</script>";
	echo"<script>window.open('STU_LOGIN.php','_self')</script>";
}
else{echo"<script>alert('Form registration failed')</script>";}
} }
 ?>



<HTML>
<HEAD>
<TITLE>STUDENT REGISTRATION FORM</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}

TD {

	PADDING: PX;
}

TD input[type="text"], input[type="password"]
{
border:none;
border-bottom:1px solid #fff;
background:transparent;
outline:none;
height:40px;
color:#fff;
font-size:16px;
}

</STYLE>

</HEAD>

<BODY BACKGROUND="img/RG1.jpg">
	<?php include 'HEADER.php'; ?>
<?php include 'connect.php'; ?>

<CENTER>
	<BR><BR><BR><BR>
<B><U><FONT SIZE="5" COLOR="ORANGE">STUDENT REGISTRATION FORM</FONT></U></B>
<BR><BR>
<form method="POST" action="#" enctype="multipart/form-data">
<TABLE>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">STUDENT'S NAME</FONT></TD>
<TD><input type="text" name="stu_name" placeholder="IN BLOCK LETTERS" autofocus="autofocus" required=""></TD>

</TR>


<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">ROLL NUMBER</FONT></TD>
<TD><input type="text" name="roll_no" placeholder=""  required=""></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">COURSE</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="course" required=""></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">YEAR</FONT></TD>
<TD><SELECT name="year" required="">
	<OPTION VALUE="1ST YEAR" >1ST YEAR</OPTION>
	<OPTION VALUE="1ST YEAR" >2ND YEAR</OPTION>
	<OPTION VALUE="1ST YEAR">3RD YEAR</OPTION>

</SELECT></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">D.O.B</FONT></TD>
<TD><INPUT TYPE="DATE" NAME="dob" required=""></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">MOBILE No.</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="mob_no" required=""></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">MAIL</FONT></TD>
<TD><INPUT TYPE="email" NAME="mail_id" required=""></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">PHOTO</FONT></TD>
<TD><INPUT TYPE="FILE" NAME="photo" required=""></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">ADDRESS</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="address" required=""></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">PASSWORD</FONT></TD>
<TD><INPUT TYPE="PASSWORD" NAME="password" required=""></TD>

</TR>

<TR>
	<TD COLSPAN="2" ALIGN="CENTER">
		<INPUT TYPE="SUBMIT" VALUE="SUBMIT" NAME="submit">
	</TD>
</TR>


	</TABLE></form>

</CENTER>
</BODY>
</HTML>
