


<?php
			session_start();
			if(isset($_SESSION['event']))
			{ }
				else
			{
				header('location:login.php');
			}

			?>



<HTML>
<HEAD>
<TITLE>CHANGE PASSWORD</TITLE>
<STYLE>

BODY{

	background-size: COVER;
	OPACITY: ;
}

TD {

	PADDING: 16PX;
}


.AA{
border:NONE;
border-bottom:1px solid #fff;
background-color:transparent;
outline:none;
height:40px;
color:ORANGE;
font-size:19px;
text-decoration: UNDERLINE;
MARGIN: 6PX;
border-right: 2PX;
}

.AA:HOVER{
color:GREEN;
CURSOR: POINTER;


}

.MAIN:HOVER{

COLOR: CRIMSON;
CURSOR: POINTER;
COLOR: LIGHTGREEN;
}
</STYLE>

</HEAD>

<BODY BACKGROUND="img/EVENT3.JPG">
<?php include 'EVENT HEAD.php'; ?>

<CENTER>
	<BR><BR><BR><BR>
<B><U><FONT SIZE="5" COLOR="YELLOW" CLASS="MAIN">VIEW EVENT DETAIL</FONT></U></B>
<BR><BR>
<TABLE>

<TR>
	<TD CLASS="AA"><B>SL. NO.</B></TD>
	<TD CLASS="AA"><B>EVENT NAME</B></TD>
	<TD CLASS="AA"><B>START DATE</B></TD>
	<TD CLASS="AA"><B>END DATE</B></TD>
	<TD CLASS="AA"><B>NO. OF PARTICIPANTS</B></TD>
	<TD CLASS="AA"><B>DESCRIPTION</B></TD>
	<TD CLASS="AA"><B>IMAGE</B></TD>
	
	<TD CLASS="AA"><B>DELETE</B></TD>
	
</TR>
<?php
include 'connect.php';
$que = "select * from event  order by eve_id desc";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{
    
    $eve_id=$row['eve_id'];
    $eve_name=$row['eve_name'];
    $st_dt = $row['st_dt'];
$end_dt = $row['end_dt'];
$num_part = $row['num_part'];
$descr = $row['descr'];
$img = $row['img'];
    
?>
<tr>
	<td><font color="white">	<?php echo $i++; ?></font></td>
	<td><font color="white">	<?php echo $eve_name; ?></font></td>
	<td><font color="white">	<?php echo $st_dt; ?></font></td>
	<td><font color="white">	<?php echo $end_dt; ?></font></td>
	<td><font color="white">	<?php echo $num_part; ?></font></td>
	<td><font color="white">	<?php echo $descr; ?></font></td>
	<td>	<img src="upload_images/<?php echo $img; ?>" height="50" width="50" ></td>
<td><a href="DEL_EVENT.php?del=<?php echo $eve_id; ?>" style="background-color:red;color:white;border-radius:18px;padding:8px 15px;text-decoration:none;">delete</a></td>
<?php } ?>

	</tr>
	</TABLE>
	</BODY>
</HTML>