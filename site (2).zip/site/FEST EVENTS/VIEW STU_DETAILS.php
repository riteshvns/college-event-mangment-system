

<?php
			session_start();
			if(isset($_SESSION['event']))
			{ }
				else
			{
				header('location:login.php');
			}

			?>


<HTML>
<HEAD>
<TITLE>VIEW STUDENT PROFILE</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}

TD {

	padding-right: -2PX;
}


.AA{
border:NONE;
border-bottom:1px solid #fff;
background-color:transparent;
outline:none;
height:40px;
color:DarkMagenta;
font-size:19px;
text-decoration: UNDERLINE;
MARGIN: 1PX;
/*border-right: 2PX;*/
}

.AA:HOVER{
color:GREEN;
CURSOR: POINTER;


}

.MAIN:HOVER{

COLOR: CRIMSON;
CURSOR: POINTER;
COLOR: DarkSlateGrey;
}
</STYLE>

</HEAD>

<BODY BACKGROUND="img/VS.JPG">
<?php include 'EVENT HEAD.php'; ?>

<CENTER>
	<BR><BR><BR><BR>
<B><U><FONT SIZE="5" COLOR="CRIMSON" CLASS="MAIN">VIEW STUDENT DETAIL</FONT></U></B>
<BR><BR>
<TABLE>

<TR>
	<TD CLASS="AA"><B>SL. NO.</B></TD>
	<TD CLASS="AA"><B>PHOTO</B></TD>
	<TD CLASS="AA"><B>STUDENT NAME</B></TD>
	<TD CLASS="AA"><B>ROLL NO</B></TD>
	<TD CLASS="AA"><B>COURSE</B></TD>
	<TD CLASS="AA"><B>YEAR</B></TD>
	<TD CLASS="AA"><B>DOB</B></TD>
	<TD CLASS="AA"><B>MOB NO</B></TD>
	<TD CLASS="AA"><B>MAIL</B></TD>
		
	<TD CLASS="AA"><B>ADDRESS</B></TD>
	<TD CLASS="AA"><B>USERNAME</B></TD>
	<TD CLASS="AA"><B>PASSWORD</B></TD>
	<TD CLASS="AA"><B>EDIT</B></TD>
	<TD CLASS="AA"><B>DELETE</B></TD>


</TR>




<?php
include 'connect.php';
$que = "select * from reg_form  order by reg_id desc";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{




    
    $reg_id=$row['reg_id'];
    $stu_name = $row['stu_name'];
$roll_no = $row['roll_no'];
$course = $row['course'];
$year = $row['year'];
$dob = $row['dob'];
$mob_no = $row['mob_no'];
$mail_id = $row['mail_id'];
$address = $row['address'];
$password = $row['password'];
$photo = $row['photo'];
    
?>
<tr>
	<td>	<?php echo $i++; ?></td>
	<td>	<IMG SRC="upload_images/<?php echo $photo; ?>" height="70" width="70"></td>
	<td>	<?php echo $stu_name; ?></td>
	<td>	<?php echo $roll_no; ?></td>
	<td>	<?php echo $course; ?></td>
	<td>	<?php echo $year; ?></td>
	<td>	<?php echo $dob; ?></td>
	<td>	<?php echo $mob_no; ?></td>
	<td>	<?php echo $mail_id; ?></td>
	
	<td>	<?php echo $address; ?></td>
	<td>	<?php echo $mail_id; ?></td>
	<td>	<?php echo $password; ?></td>

<td><a href="EVENT UPDATE1.php?edit=<?php echo $reg_id;?>" style="background-color:blue;color:white;border-radius:18px;padding:8px 15px;text-decoration:none;">Edit</a></td>
<td><a href="DEL_STU.php?del=<?php echo $reg_id; ?>" style="background-color:red;color:white;border-radius:18px;padding:8px 15px;text-decoration:none;">delete</a></td></tr>
<?php } ?>

	



	</TABLE>
	</BODY>
</HTML>