

<?php
			session_start();
			if(isset($_SESSION['event']))
			{ }
				else
			{
				header('location:login.php');
			}

			?>


<?php
include('connect.php');
if(isset($_POST['submit']))
{
	
		$password=$_POST['password'];
		$npassword=$_POST['npassword'];
		
			$qry="SELECT * FROM `admin_login` WHERE password='$password' ";
$run= mysqli_query($con,$qry);
$row=mysqli_num_rows($run);
	if($row<1)
		{?>
			<script>alert('Old Password Not Match !! ') ;
			window.open('CHANGE PASSWORD.php','_self');
			</script>
			
			<?php
		}
		
		else
		{
		$upd="UPDATE `admin_login` SET `password` = '$npassword'  ";
		$run= mysqli_query($con,$upd);
		
		?>	

		<script>alert('Password Updated Successfully !!');
			window.open('EVENT HEAD.php','_self');
			</script>
		
							
		<?php	
		}
}
?>

<HTML>
<HEAD>
<TITLE>CHANGE PASSWORD</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}

TD {

	PADDING: PX;
}

TD input[type="text"], input[type="password"]
{
border:none;
border-bottom:1px solid #fff;
background:transparent;
outline:none;
height:40px;
color:#fff;
font-size:16px;
}

</STYLE>

</HEAD>

<BODY BACKGROUND="img/RG1.JPG">
<?php include 'EVENT HEAD.php'; ?>
	
<CENTER>
	<BR><BR><BR><BR>
<B><U><FONT SIZE="5" COLOR="GoldenRod">CHANGE PASSWORD </FONT></U></B>
<BR><BR>

<form method="POST" ACTION="#">
<TABLE>


<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">OLD PASSWORD</FONT></TD>
<TD><input type="PASSWORD" name="password"  autofocus="autofocus" required=""></TD>

</TR>


<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">NEW PASSWORD</FONT></TD>
<TD><INPUT TYPE="PASSWORD" NAME="npassword"></TD>

</TR>


<TR><TD COLSPAN="2" ALIGN="CENTER">
		<INPUT TYPE="SUBMIT" VALUE="CHANGE" NAME="submit">
	
	</TD>

	</TR>


	</TABLE>
</form>
</CENTER>
</BODY>
</HTML>
