<?php
			session_start();
			if(isset($_SESSION['stu_event']))
			{ 
$stu_event=$_SESSION['stu_event'];
			}
				else
			{
				header('location:STU_LOGIN.php');
			}

			?>	


<HTML>
<HEAD>
<TITLE>JOIN FEST</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}

TD {

	PADDING: PX;
}

TD input[type="text"], input[type="password"]
{
border:none;
border-bottom:1px solid #fff;
background:transparent;
outline:none;
height:40px;
color:#fff;
font-size:16px;
}

</STYLE>

</HEAD>

<BODY BACKGROUND="img/RG1.JPG">
<?php include 'EDIT BY STUDENT.php';?>

<CENTER>
	<BR><BR><BR><BR>
<B><U><FONT SIZE="5" COLOR="GoldenRod">JOIN FEST </FONT></U></B>
<BR><BR>
<form method="POST" action="#">
<TABLE>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">EVENT NAME</FONT></TD>
<TD><SELECT name="eve_name">
	<?php
include 'connect.php';
$que = "select * from event  order by eve_id desc";
$run = mysqli_query($con,$que);
while($row=mysqli_fetch_array($run))
{
    
    $eve_id=$row['eve_id'];
    $eve_name=$row['eve_name'];
       
?>
	<OPTION VALUE="<?php echo $eve_name;?>"><?php echo $eve_name;?></OPTION>
	
<?php } ?>
</SELECT></TD>

</TR>

<TR><TD COLSPAN="2" ALIGN="CENTER">
		<INPUT TYPE="SUBMIT" VALUE="JOIN EVENT" NAME="submit">
	
	</TD>

	</TR>


	</TABLE>
</form>
</CENTER>
</BODY>
</HTML>
<?php 
include 'connect.php';

if(isset($_POST['submit'])){

$eve_name = $_POST['eve_name']; 

$query = mysqli_query($con,"INSERT INTO `join_event`( `eve_name`, `mail_id`) VALUES ('$eve_name', '$stu_event')");
if($query)
{
	echo"<script>alert('Event Join successfully')</script>";
	echo"<script>window.open('VIEW PROFILE.php','_self')</script>";
}
else{echo"<script>alert('Event Join failed')</script>";}
} 
 ?>