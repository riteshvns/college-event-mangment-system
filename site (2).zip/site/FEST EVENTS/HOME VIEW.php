<HTML>
<HEAD>
<TITLE>HOME 2</TITLE>
<style>

.image11{
display:block;
height:450px;
width:400px;
/*border-radius: 30px;*/
}

.image{
display:block;
height:100%;
width:100%;
border-radius: 30px;
}
td{

	border: none;
}


.containerR{
position:relative;
height:45%;
width:28%;
margin-left:25px;
/*margin-top:150px;*/
background-color:black;
border-radius: 30px;
float: left;

}



.containerR:HOVER{

BORDER-RADIUS: 30PX;
TRANSITION: 2S;
BOX-SHADOW: 50PX BLACK;


}
.containerR:HOVER .image{


BORDER-RADIUS: 30PX;

TRANSITION: 2S;
}


	</style>
</HEAD>
<BODY>
	<?php include 'HEADER.php'; 
	$eve_id=$_GET['next'];
	?>



<center>
	<table border="0" height="80%" width="80%">
<?php
include 'connect.php';
$que = "select * from event  where `eve_id`= '$eve_id' ";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{
    
    $eve_id=$row['eve_id'];
    $eve_name=$row['eve_name'];
    $st_dt = $row['st_dt'];
$end_dt = $row['end_dt'];
$num_part = $row['num_part'];
$descr = $row['descr'];
$img = $row['img'];?>

<td bgcolor="PaleGoldenRod"><img src="upload_images/<?php echo $img; ?>" class="image11"></td>

<td bgcolor="PaleGoldenRod"><?php echo $descr; ?> </td>
<?php } ?>
	</table>
</center>



<br><br><br>
<?php
include 'connect.php';
$que = "select * from event_images  where `event_name`='$eve_name' order by img_id desc";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{    
    $img_id=$row['img_id'];
    $event_name = $row['event_name'];
$event_img = $row['event_img'];

?>
<div class="containerR">
<img src="upload_images/<?php echo $event_img; ?>"  class="image">
</div>
<?php } ?>
</BODY>
</HTML>