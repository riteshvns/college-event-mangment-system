<?php
session_start();
include('connect.php');
if(isset($_POST['submit']))
{
	
		$username=$_POST['username'];
		$password=$_POST['password'];
		
		$qry="SELECT * FROM `admin_login` WHERE `username`='$username' AND `password`='$password'";
		$run=mysqli_query($con,$qry);
		
		$row=mysqli_num_rows($run);
		if($row<1)
		{?>
			<script>alert('username or password not match !!');
			window.open('LOGIN.php','_self');
			</script>
			
			<?php
			
		}
		
		else
		{
			
						
			$data=mysqli_fetch_assoc($run);
			$_SESSION['event']=$data['username'];
			
			
			header('location:EVENT HEAD.php');
		}
}
?>




<html>
<head>
<title>login</title>

<link rel="stylesheet" type="text/css" href="css/csslogin.css">
<link rel="stylesheet" type="text/css" href="css/HOME.css">
</head>
<body>
<?php include 'HEADER.php'; ?>

<div class="aaa">
<div class="loginbox" >
<img src="img/login1.jpg" class="avatar" class="overlay">

<h1>ADMIN LOGIN</h1>
<form method="POST" action="#">
<p>Username</p>
<input type="text" name="username" placeholder="Enter Username" autofocus="autofocus" required="">
<p>Password</p>
<input type="password" name="password" placeholder="Enter Password" required="">
<input type="submit" name="submit" value="login">
<a href="#">Don't have an Account?</a>
</form>
</div>
</div>

</body>
</html>
