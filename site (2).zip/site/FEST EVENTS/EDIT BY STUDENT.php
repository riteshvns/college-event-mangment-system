<HTML>
<HEAD>
<TITLE>EDIT BY STUDENT</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}




TD {

	PADDING: 6PX;
}


.AA{
border:NONE;
border-bottom:1px solid #fff;
background-color:transparent;
outline:none;
height:40px;
color:ORANGE;
font-size:19px;
text-decoration: UNDERLINE;
MARGIN: 6PX;
border-right: 2PX;
}

.AA:HOVER{
color:GREEN;
CURSOR: POINTER;


}

.MAIN:HOVER{

COLOR: CRIMSON;
CURSOR: POINTER;
COLOR: LIGHTGREEN;
}



.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}

.chng{

text-decoration: none;
color: white;

}



.AA1{
border:NONE;
border-bottom:1px solid #fff;
background-color:transparent;
outline:none;
height:40px;
color:GoldenRod;
font-size:19px;
text-decoration: UNDERLINE;
MARGIN: 6PX;
border-right: 2PX;
}

.AA1:HOVER{
color:GREEN;
CURSOR: POINTER;


}

.MAIN:HOVER{

COLOR: orange;
CURSOR: POINTER;

}
.ccc{

text-decoration: none;
color: GoldenRod;



}

.ccc:hover{
color: green;
cursor: pointer;


}

</STYLE>

</HEAD>

<BODY BACKGROUND="img/H13.JPG">
<CENTER>
	<BR>
<B><U><FONT SIZE="5" COLOR="CRIMSON" CLASS="MAIN">WELCOME</FONT></U></B>
<BR><BR>
<TABLE>


<TR>
<TD CLASS="AA">
    

<a href="VIEW PROFILE.php" class="chng"><div class="dropdown">
  <button class="dropbtn">HOME</button>
</div></a>

</TD>


<TD CLASS="AA">
    

<a href="EVENT UPDATE.php" class="chng"><div class="dropdown">
  <button class="dropbtn">EDIT PROFILE</button>
</div></a>

</TD>

<TD CLASS="AA">
    

<a href="STU JOIN FEST.php" class="chng"><div class="dropdown">
  <button class="dropbtn">REGISTER FOR FEST</button>
</div></a>

</TD>

<TD CLASS="AA">
    

<a href="STU CHANGE PASSWORD.php" class="chng"><div class="dropdown">
  <button class="dropbtn">CHANGE PASSWORD</button>
</div></a>

</TD>



<TD CLASS="AA">
    

<a href="logout.php" class="chng"><div class="dropdown">
  <button class="dropbtn">LOGOUT</button>
</div></a>

</TD>




	</TABLE>
	</BODY>
</HTML>