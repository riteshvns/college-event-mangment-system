
<?php
			session_start();
			if(isset($_SESSION['stu_event']))
			{ 
$stu_event=$_SESSION['stu_event'];
			}
				else
			{
				header('location:STU_LOGIN.php');
			}

			?>
<HTML>
<HEAD>
<TITLE>VIEW STUDENT PROFILE</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}

TD {

	PADDING: 6PX;
}


.AA{
border:NONE;
border-bottom:1px solid #fff;
background-color:transparent;
outline:none;
height:40px;
color:DarkMagenta;
font-size:19px;
text-decoration: UNDERLINE;
MARGIN: 6PX;
border-right: 2PX;
}

.AA:HOVER{
color:GREEN;
CURSOR: POINTER;


}
DIV{


	background-color: ;
	HEIGHT:;
}
.BB{

	background-color: AntiqueWhite;
	BORDER-RADIUS: 20PX;
	COLOR: DARKRED;
	text-decoration: underline;
	WIDTH: 100PX;

}

.DD{

	background-color: AntiqueWhite;
	BORDER-RADIUS: 20PX;
	COLOR: DARKRED;
	text-decoration: underline;

}


</STYLE>

</HEAD>

<BODY >
<?php include 'EDIT BY STUDENT.php'; ?>

<CENTER>
	

	<BR>
<TABLE BORDER="0">

<?php
include 'connect.php';
$que = "select * from reg_form  where mail_id='$stu_event'";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{




    
    $reg_id=$row['reg_id'];
    $stu_name = $row['stu_name'];
$roll_no = $row['roll_no'];
$course = $row['course'];
$year = $row['year'];
$dob = $row['dob'];
$mob_no = $row['mob_no'];
$mail_id = $row['mail_id'];
$address = $row['address'];
$password = $row['password'];
$photo = $row['photo'];
    
?>
<TR>
	

	<TD COLSPAN="3" ROWSPAN="4" VALIGN="TOP" CLASS="BB" ALIGN="CENTER"><DIV><img src="upload_images/<?php echo $photo; ?>" height="100" width="70"></DIV></TD>
<TD><FONT SIZE="3" COLOR="WHITE">STUDENT'S NAME</FONT></TD>
<TD><input type="text" name="" value="<?php echo $stu_name; ?>" autofocus="autofocus" required="" readonly></TD>


<TD COLSPAN="3" ROWSPAN="4" VALIGN="TOP" CLASS="BB" ALIGN="CENTER"><DIV>RESULT</DIV><marquee direction="up" onmouseover="this.stop();" onmouseout="this.start();" scrollamount="2">
<?php
include 'connect.php';
$que = "select * from result  order by res_id desc";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{
    
    $res_id=$row['res_id'];
    $res_desc=$row['res_desc'];
   
    
?>
<li><b style="color:black;"><?php echo $res_desc; ?></b></li>

<?php } ?></marquee>
</TD>
</TR>


<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">COURSE</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="" value="<?php echo $course; ?>" readonly></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">YEAR</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="" value="<?php echo $year; ?>" readonly></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">D.O.B</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="" value="<?php echo $dob; ?>" readonly></TD>

</TR>

<TR>


<TD COLSPAN="3" ROWSPAN="5" VALIGN="TOP" CLASS="DDD"></TD>	
<TD><FONT SIZE="3" COLOR="WHITE" >MOBILE No.</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="" value="<?php echo $mob_no; ?>" readonly></TD>
<TD COLSPAN="3" ROWSPAN="5" VALIGN="TOP" CLASS="DD" align="center">NOTIFICATION
	<marquee direction="up" onmouseover="this.stop();" onmouseout="this.start();" scrollamount="2">
<?php
include 'connect.php';
$que = "select * from notice  order by note_id desc";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{
    
    $note_id=$row['note_id'];
    $note_desc=$row['note_desc'];
   
    
?>
<li><b style="color:black;"><?php echo $res_desc; ?></b></li>

<?php } ?>

</marquee>

</TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">MAIL</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="" value="<?php echo $mail_id; ?>" readonly></TD>

</TR>


<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">ADDRESS</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="" value="<?php echo $address; ?>" readonly></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">PASSWORD</FONT></TD>
<TD><INPUT TYPE="PASSWORD" NAME="" value="<?php echo $password; ?>" readonly></TD>

</TR> <?php } ?>

<!-- <TR>
	<TD COLSPAN="2" ALIGN="CENTER">
		<INPUT TYPE="SUBMIT" VALUE="SUBMIT" NAME="">
	</TD>
</TR>
 -->

	</TABLE>

</CENTER>




<CENTER>
	<BR><BR><BR><BR>
<B><U><FONT SIZE="5" COLOR="Chocolate">JOINED EVENTS</FONT></U></B>
<BR><BR>
<TABLE>

<TR><TD CLASS="AA"><B>Sl. No. </B></TD>
	<TD CLASS="AA"><B>EVENT NAME</B></TD>
	</TR>
	<?php
include 'connect.php';
$que = "select * from join_event where `mail_id`='$stu_event'  order by join_id desc";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{
   
    $eve_name=$row['eve_name'];
   
    
?>
<TR><td style="color: white"><?php echo $i++; ?></td>
	<TD style="color: white"><B><?php echo $eve_name;?></B></TD>
		</TR>
	<?php }?>
	</TABLE>


</BODY>
</HTML>
