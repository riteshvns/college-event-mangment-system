<html>
<head>
<title>HOME</title>





<!-- <link rel="stylesheet" type="text/css" href="css/csslogin.css"> -->
<link rel="stylesheet" type="text/css" href="css/HOME.css">

<STYLE>

.containerR{
position:relative;
height:35%;
width:18%;
margin-left:25px;
/*margin-top:150px;*/
background-color:black;
float: left;
margin-top: 10px;
border: none;
}



.containerR:HOVER{

BORDER-RADIUS: 30PX;
TRANSITION: 2S;
BOX-SHADOW: 50PX BLACK;


}
.containerR:HOVER .image{


BORDER-RADIUS: 30PX;

TRANSITION: 2S;

}


.image{
display:block;
height:100%;
width:100%;

}
.overlay{
position:absolute;
top:0;
bottom:50%;
height:50%;
width:0;
left:0;
right:100%;
background-color:DeepSkyBlue;
transition:.5s;
opacity:0;
cursor:pointer;
}

.overlayy{
position:absolute;
top:50%;
bottom:0;
height:50%;
width:0;
left:100%;
right:0;
background-color:DeepSkyBlue;
transition:.5s;
opacity:0;
cursor:pointer;
}
.containerR:hover .overlay{
width:100%;
right:0;

opacity:.6;
transition:1s;
border-top-left-radius: 30PX;
border-top-right-radius: 30PX;
}

.containerR:hover .overlayy{
width:100%;
left:0;

opacity:.6;
transition:1s;
border-bottom-left-radius: 30PX;
border-bottom-right-radius: 30PX;
}
.text{
position:absolute;
color:BLACK;
font-size:20px;
top:50%;
left:50%;
transform:translate(-50%,-50%);


}


	</STYLE>

</head>
<body>

	<?php include 'HEADER.php'; ?>
<!-- <hr class="h">
<div class="a">
<div class="b">






	<div class="c"><div class="lg">e</div></div>
<div  class="blinking">n</div>
<div  class="blinking1">j</div>
<div class="c"><div  class="lg">o</div></div>
<div  class="blinking2">y</div> 


<div class="c"><div class="lg">e</div></div>
<div  class="blinking">v</div>
<div  class="blinking1">e</div>
<div class="c"><div  class="lg">n</div></div>
<div  class="blinking2">t</div>
<div  class="blinking2">s</div>
</div>




<div align="right" class="aa"><A HREF="STU_LOGIN.HTML">STUDENT LOGIN</A></div>
<div align="right" class="aa"><A HREF="LOGIN.HTML">ADMIN LOGIN</A></div>
<div align="right" class="aa2"><A HREF="#">HOME</A></div>
</div>
<hr class="h"> -->

<div class="i"><img src="img/H2.jpg" class="immage">


</div>



<!-- <div class="a1">
<center>
<table class="t1">

<tr><td align="center"><b>ALL PACKAGES</b></td><td align="center"><b>SEARCH BY</b></td></tr>
<tr align="center"><td></td><td><input type="text" name="sb_cost" size="11"></tr>
</center>
</div>
 -->

 
<!-- <div class="a1"> -->
<center>




<!-- <div class="b">

<img src="img/index.png"></div> -->




	




<!-- <table class="t1">

<tr><td align="center"><b>ALL PACKAGES</b></td><td align="center"><b>SEARCH BY</b></td></tr>
<tr align="center"><td></td><td><input type="text" name="sb_cost" size="11"></tr>
</center> -->
</div><BR>



<!--   -----------------------DIV FOR FEST-----------------------    -->
<?php
include 'connect.php';
$que = "select * from event  order by eve_id desc";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{
    
    $eve_id=$row['eve_id'];
    $eve_name=$row['eve_name'];
    $st_dt = $row['st_dt'];
$end_dt = $row['end_dt'];
$num_part = $row['num_part'];
$descr = $row['descr'];
$img = $row['img'];
    
?><a href="HOME VIEW.php?next=<?php echo $eve_id;?>">
<div class="containerR">
<img src="upload_images/<?php echo $img; ?>"  class="image">
<div class="overlay">
<div class="text">EVENT <BR>OF  </div>
</div>
<div class="overlayy">
<div class="text"><?php echo $eve_name; ?></div>
</div>

</div></a><?php } ?>
<BR><BR><BR><BR><BR><BR><BR><BR>

<!--   -----------------------DIV FOR FEST-----------------------    -->

</body>
</html>
