
<?php
			session_start();
			if(isset($_SESSION['event']))
			{ }
				else
			{
				header('location:login.php');
			}

			?>


<?php 
include 'connect.php';

if(isset($_POST['submit'])){


$note_desc = $_POST['note_desc'];

 

$query = mysqli_query($con,"INSERT INTO `notice`(`note_desc`) VALUES ('$note_desc')");
if($query)
{
	echo"<script>alert('Description added successfully')</script>";
	echo"<script>window.open('NOTIFICATION.php','_self')</script>";
}
else{echo"<script>alert('Description  failed')</script>";}
} 
 ?>


<HTML>
<HEAD>
<TITLE>NOTIFICATION</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}

TD {

	PADDING: PX;
}

TD input[type="text"], input[type="password"]
{
border:none;
border-bottom:1px solid #fff;
background:transparent;
outline:none;
height:40px;
color:#fff;
font-size:16px;
}

.TXT{
border:NONE;
border-bottom:1px solid #fff;
background-color:transparent;
outline:none;
height:40px;
color:ORANGE;
font-size:19px;
text-decoration: UNDERLINE;
MARGIN: 6PX;
border-right: 2PX;
PADDING: 16PX;
}

.TXT:HOVER{
color:GREEN;
CURSOR: POINTER;


}
TD {

	PADDING: 16PX;
}





</STYLE>

</HEAD>

<BODY BACKGROUND="img/RG1.JPG">
<?php include 'EVENT HEAD.php'; ?>
<?php include 'connect.php'; ?>

<CENTER>
	<BR><BR><BR><BR>
<B><U><FONT SIZE="5" COLOR="GoldenRod">NOTIFICATION</FONT></U></B>
<BR><BR>
<form method="POST" action="#" enctype="multipart/form-data">

<TABLE>



<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">DESCRIPTION</FONT></TD>
<TD><TEXTAREA ROWS="10" COLS="60" name="note_desc" required=""></TEXTAREA></TD>

</TR>


<TR><TD COLSPAN="2" ALIGN="CENTER">
		<INPUT TYPE="SUBMIT" VALUE="SUBMIT" NAME="submit">
	
	</TD>

	</TR>


	</TABLE>

<CENTER>
	<BR><BR><BR><BR>

	<a name="vn"></a><br><br>
<B><U><FONT SIZE="5" COLOR="YELLOW" CLASS="MAIN">VIEW NOTIFICATIONS</FONT></U></B>
<BR><BR>
<TABLE>

<TR>
	<TD CLASS="TXT"><B>S.R NO.</B></TD>
	<TD CLASS="TXT"><B>DESCRIPTION</B></TD>
	<TD CLASS="TXT"><B>DELETE</B></TD></TR>




<?php
include 'connect.php';
$que = "select * from notice  order by note_id desc";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{
    
    $note_id=$row['note_id'];
    $note_desc=$row['note_desc'];
   
    
?>
<tr>
	<td><font color="white">	<?php echo $i++; ?></font></td>
	<td>	<font color="white"><?php echo $note_desc; ?></font></td>
	

<td><a href="DEL_NOTE.php?del=<?php echo $note_id; ?>" style="background-color:red;color:white;border-radius:18px;padding:8px 15px;text-decoration:none;">delete</a></td>
<?php } ?>

	</tr>




</TABLE><form>

</CENTER>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<a href="#top"><div align="right"><FONT COLOR="WHITE" SIZE="3">TOP</FONT></div></a>


</BODY>
</HTML>
