
<?php
			session_start();
			if(isset($_SESSION['event']))
			{ }
				else
			{
				header('location:login.php');
			}

			?>
<?php
	include 'connect.php';
	$id= $_GET['del'];

	$qry="DELETE FROM `reg_form` WHERE `reg_id` ='$id'  ";
	
$run= mysqli_query($con,$qry);
if($run== true)
{
?>
<script>
		alert('Data deleted Successfully...');
		window.open('VIEW STU_DETAILS.php','_self');
		</script>
<?php
}
?>