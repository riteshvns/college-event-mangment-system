
<?php
			session_start();
			if(isset($_SESSION['event']))
			{ }
				else
			{
				header('location:login.php');
			}

			?>

<?php 
include 'connect.php';

if(isset($_POST['submit'])){

$event_img=$_FILES['event_img']['name'];
$img_tmp=$_FILES['event_img']['tmp_name'];
move_uploaded_file($img_tmp,"upload_images/$event_img");

$event_name = $_POST['event_name'];



 

$query = mysqli_query($con,"INSERT INTO `event_images`(`event_name`, `event_img`) VALUES ('$event_name', '$event_img')");
if($query)
{
	echo"<script>alert('Image uploaded successfully')</script>";
	echo"<script>window.open('EVENT IMG UP.php','_self')</script>";
}
else{echo"<script>alert('Image uploaded failed')</script>";}
} 
 ?>


<HTML>
<HEAD>
<TITLE>UPLOAD IMAGES</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}

TD {

	PADDING: PX;
}

TD input[type="text"], input[type="password"]
{
border:none;
border-bottom:1px solid #fff;
background:transparent;
outline:none;
height:40px;
color:#fff;
font-size:16px;
}
.TXT{
border:NONE;
border-bottom:1px solid #fff;
background-color:transparent;
outline:none;
height:40px;
color:ORANGE;
font-size:19px;
text-decoration: UNDERLINE;
MARGIN: 6PX;
border-right: 2PX;
PADDING: 16PX;
}

.TXT:HOVER{
color:GREEN;
CURSOR: POINTER;


}
TD {

	PADDING: 16PX;
}



</STYLE>

</HEAD>

<BODY BACKGROUND="img/RG1.JPG">
<?php include 'EVENT HEAD.php'; ?>
<?php include 'connect.php'; ?>

<CENTER>
	<BR><BR><BR><BR>
<B><U><FONT SIZE="5" COLOR="GoldenRod">UPLOAD IMAGES </FONT></U></B>
<BR><BR>

<form method="POST" action="#" enctype="multipart/form-data">
<TABLE>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">EVENT NAME</FONT></TD>
<TD><SELECT name="event_name" required="">
	<?php
include 'connect.php';
$que = "select * from event  order by eve_id desc";
$run = mysqli_query($con,$que);
while($row=mysqli_fetch_array($run))
{
    
    $eve_id=$row['eve_id'];
    $eve_name=$row['eve_name'];
       
?>
	<OPTION VALUE="<?php echo $eve_name;?>"><?php echo $eve_name;?></OPTION>
	
<?php } ?>
</SELECT></TD>

</TR>
<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">EVENT IMAGE</FONT></TD>
<TD><INPUT TYPE="FILE" NAME="event_img" required=""></TD>

</TR>






<TR><TD COLSPAN="2" ALIGN="CENTER">
		<INPUT TYPE="SUBMIT" VALUE="SUBMIT" NAME="submit">
	
	</TD>

	</TR>


<!-- <TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">DESCRIPTION</FONT></TD>
<TD><TEXTAREA ROWS="10" COLS="30"></TEXTAREA></TD>

</TR> -->


	</TABLE></form>

</CENTER>


<CENTER>
	<BR><BR><BR><BR>

<a name="vi"></a><br><br>

<B><U><FONT SIZE="5" COLOR="YELLOW" CLASS="MAIN">VIEW IMAGES</FONT></U></B>
<BR><BR>
<TABLE>

<TR>
	<TD CLASS="TXT"><B>S.R NO.</B></TD>
	<TD CLASS="TXT"><B>EVENT NAME</B></TD>
	<TD CLASS="TXT"><B>EVENT IMAGE</B></TD>
	
	<TD CLASS="TXT"><B>DELETE</B></TD></TR>





<?php
include 'connect.php';
$que = "select * from event_images  order by img_id desc";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{




    
    $img_id=$row['img_id'];
    $event_name = $row['event_name'];
$event_img = $row['event_img'];

?>
<tr>
	<td><font color="white">	<?php echo $i++; ?></font></td>

	<td><font color="white">	<?php echo $event_name; ?></font></td>
	<td>	<img src="upload_images/<?php echo $event_img; ?>" height="60" width="60"></td>

	<td><a href="DEL_EVENT_IMG.php?del=<?php echo $img_id; ?>" style="background-color:red;color:white;border-radius:18px;padding:8px 15px;text-decoration:none;">delete</a></td>
<?php } ?>

</TABLE>

</CENTER>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<a href="#top"><div align="right"><FONT COLOR="WHITE" SIZE="3">TOP</FONT></div></a>

</BODY>
</HTML>
