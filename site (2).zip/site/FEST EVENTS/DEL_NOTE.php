
<?php
			session_start();
			if(isset($_SESSION['event']))
			{ }
				else
			{
				header('location:login.php');
			}

			?>
<?php
	include 'connect.php';
	$id= $_GET['del'];

	$qry="DELETE FROM `notice` WHERE `note_id` ='$id'  ";
	
$run= mysqli_query($con,$qry);
if($run== true)
{
?>
<script>
		alert('Data deleted Successfully...');
		window.open('RESULT.php','_self');
		</script>
<?php
}
?>