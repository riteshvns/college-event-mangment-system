

<?php
			session_start();
			if(isset($_SESSION['event']))
			{ }
				else
			{
				header('location:login.php');
			}

			?>


<?php 
include 'connect.php';

if(isset($_POST['submit'])){


$res_desc = $_POST['res_desc'];

 

$query = mysqli_query($con,"INSERT INTO `result`(`res_desc`) VALUES ('$res_desc')");
if($query)
{
	echo"<script>alert('Description added successfully')</script>";
	echo"<script>window.open('RESULT.php','_self')</script>";
}
else{echo"<script>alert('Description  failed')</script>";}
} 
 ?>


<HTML>
<HEAD>
<TITLE>RESULT</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}

TD {

	PADDING: PX;
}

TD input[type="text"], input[type="password"]
{
border:none;
border-bottom:1px solid #fff;
background:transparent;
outline:none;
height:40px;
color:#fff;
font-size:16px;
}

.TXT{
border:NONE;
border-bottom:1px solid #fff;
background-color:transparent;
outline:none;
height:40px;
color:ORANGE;
font-size:19px;
text-decoration: UNDERLINE;
MARGIN: 6PX;
border-right: 2PX;
PADDING: 16PX;
}

.TXT:HOVER{
color:GREEN;
CURSOR: POINTER;


}
TD {

	PADDING: 16PX;
}





</STYLE>

</HEAD>

<BODY BACKGROUND="img/RG1.JPG">
<?php include 'EVENT HEAD.php'; ?>
<?php include 'connect.php'; ?>

<CENTER>
	<BR><BR><BR><BR>
<B><U><FONT SIZE="5" COLOR="GoldenRod">RESULT</FONT></U></B>
<BR><BR>
<form method="POST" action="#" enctype="multipart/form-data">

<TABLE>



<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">DESCRIPTION</FONT></TD>
<TD><TEXTAREA ROWS="10" COLS="60" name="res_desc" required=""></TEXTAREA></TD>

</TR>


<TR><TD COLSPAN="2" ALIGN="CENTER">
		<INPUT TYPE="SUBMIT" VALUE="SUBMIT" NAME="submit">
	
	</TD>

	</TR>


	</TABLE>

	<CENTER>
	<BR><BR><BR><BR>
	<a name="vr"></a><br>
<B><U><FONT SIZE="5" COLOR="YELLOW" CLASS="MAIN">VIEW RESULT</FONT></U></B>
<BR><BR>
<TABLE>

<TR>
	<TD CLASS="TXT"><B>S.R NO.</B></TD>
	<TD CLASS="TXT"><B>DESCRIPTION</B></TD>
	<TD CLASS="TXT"><B>DELETE</B></TD></TR>





</TR>
<?php
include 'connect.php';
$que = "select * from result  order by res_id desc";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{
    
    $res_id=$row['res_id'];
    $res_desc=$row['res_desc'];
   
    
?>
<tr>
	<td>	<font color="white"><?php echo $i++; ?></font></td>
	<td>	<font color="white"><?php echo $res_desc; ?></font></td>
	

<td><a href="DEL_RESULT.php?del=<?php echo $res_id; ?>" style="background-color:red;color:white;border-radius:18px;padding:8px 15px;text-decoration:none;">delete</a></td>
<?php } ?>

	</tr>





</TABLE></FORM>
</BR>

</CENTER>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<a href="#top"><div align="right"><FONT COLOR="WHITE" SIZE="3">TOP</FONT></div></a>

</BODY>
</HTML>
