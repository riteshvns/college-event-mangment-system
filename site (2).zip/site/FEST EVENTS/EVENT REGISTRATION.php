

<?php
			session_start();
			if(isset($_SESSION['event']))
			{ }
				else
			{
				header('location:login.php');
			}

			?>



<?php 
include 'connect.php';

if(isset($_POST['submit'])){

$img=$_FILES['img']['name'];
$img_tmp=$_FILES['img']['tmp_name'];
move_uploaded_file($img_tmp,"upload_images/$img");

$eve_name = $_POST['eve_name'];
$st_dt = $_POST['st_dt'];
$end_dt = $_POST['end_dt'];
$num_part = $_POST['num_part'];
$descr = $_POST['descr'];

 

$query = mysqli_query($con,"INSERT INTO `event`( `eve_name`, `st_dt`, `end_dt`, `num_part`, `descr`, `img`) VALUES ('$eve_name', '$st_dt', '$end_dt', '$num_part', '$descr', '$img')");
if($query)
{
	echo"<script>alert('Event created successfully')</script>";
	echo"<script>window.open('EVENT DETAIL.php','_self')</script>";
}
else{echo"<script>alert('Event created failed')</script>";}
} 
 ?>


<HTML>
<HEAD>
<TITLE>STUDENT REGISTRATION FORM</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}

TD {

	PADDING: PX;
}

TD input[type="text"], input[type="password"]
{
border:none;
border-bottom:1px solid #fff;
background:transparent;
outline:none;
height:40px;
color:#fff;
font-size:16px;
}

</STYLE>

</HEAD>

<BODY BACKGROUND="img/RG1.JPG">
<?php include 'EVENT HEAD.php'; ?>
<?php include 'connect.php'; ?>

<CENTER>
	<BR><BR><BR><BR>
<B><U><FONT SIZE="5" COLOR="GoldenRod">EVENT REGISTRATION </FONT></U></B>
<BR><BR>
<form method="POST" action="#" enctype="multipart/form-data">
<TABLE>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">EVENT NAME</FONT></TD>
<TD><input type="text" name="eve_name"  autofocus="autofocus" required=""></TD>

</TR>
<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">EVENT IMAGE</FONT></TD>
<TD><INPUT TYPE="FILE" NAME="img" required=""></TD>

</TR>


<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">START DATE</FONT></TD>
<TD><INPUT TYPE="DATE" NAME="st_dt" required=""></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">END DATE</FONT></TD>
<TD><INPUT TYPE="DATE" NAME="end_dt" required="">
</TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">NO. OF PARTICIPANTS</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="num_part" required=""></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">DESCRIPTION</FONT></TD>
<TD><TEXTAREA ROWS="10" COLS="30" name="descr" required=""></TEXTAREA></TD>

</TR>


<TR><TD COLSPAN="2" ALIGN="CENTER">
		<INPUT TYPE="SUBMIT" VALUE="CREATE" NAME="submit">
	
	</TD>

	</TR>


	</TABLE>
</form>

</CENTER>
</BODY>
</HTML>
