<HTML>
<HEAD>
<TITLE>VIEW STUDENT PROFILE</TITLE>
<STYLE>

BODY{

	background-size: COVER;
	OPACITY: ;
}

TD {

	PADDING: 8PX;
}


.AA{
border:NONE;
border-bottom:1px solid #fff;
background-color:transparent;
outline:none;
height:40px;
color:ORANGE;
font-size:19px;
text-decoration: UNDERLINE;
MARGIN: 6PX;
border-right: 2PX;
}

.AA:HOVER{
color:GREEN;
CURSOR: POINTER;


}

.MAIN:HOVER{

COLOR: CRIMSON;
CURSOR: POINTER;
COLOR: LIGHTGREEN;
}



.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}

.chng{

text-decoration: none;
color: white;

}
</STYLE>

</HEAD>

<BODY BACKGROUND="">
<CENTER>
	
<B><U><FONT SIZE="5" COLOR="CRIMSON" CLASS="MAIN">WELCOME TO ADMIN</FONT></U></B>
<BR><BR>
<TABLE>

<TR>
<TD CLASS="AA">
    

<a href="VIEW STU_DETAILS.php" class="chng"><div class="dropdown">
  <button class="dropbtn"><a href="VIEW STU_DETAILS.php" class="chng">STUDENT DETAIL</button>
  <div class="dropdown-content">
  </div>
</div></a>

  </TD>

	<TD CLASS="AA"><div class="dropdown">
  <button class="dropbtn">EVENT</button>
  <div class="dropdown-content">
  <a href="EVENT REGISTRATION.php">UPLOAD</a>
  <a href="EVENT DETAIL.php">VIEW</a>
  
  </div>
</div></TD>


	<TD CLASS="AA">
		
<div class="dropdown">
  <button class="dropbtn">RESULT</button>
  <div class="dropdown-content">
  <a href="RESULT.php">UPLOAD</a>
  <a href="RESULT.php#vr">VIEW</a>
  
  </div>
</div>

	</TD>
	<TD CLASS="AA">
		
<div class="dropdown">
  <button class="dropbtn">NOTICES</button>
  <div class="dropdown-content">
  <a href="NOTIFICATION.php">UPLOAD</a>
  <a href="NOTIFICATION.php#vn">VIEW</a>
  
  </div>
</div>


	</TD>
	<TD CLASS="AA">
		
<div class="dropdown">
  <button class="dropbtn">EVENT IMAGES</button>
  <div class="dropdown-content">
  <a href="EVENT IMG UP.php">UPLOAD</a>
  <a href="EVENT IMG UP.php#vi">VIEW</a>
  
  </div>
</div>

	</TD>
	<TD CLASS="AA">
		

<a href="CHANGE PASSWORD.php" class="chng"><div class="dropdown">
  <button class="dropbtn"><a href="CHANGE PASSWORD.php" class="chng">CHANGE PASSWORD</a></button>
  <div class="dropdown-content">
  </div>
</div></a>

	</TD>
	<TD CLASS="AA">
		

<div class="dropdown">
  <a href="logout.php"><button class="dropbtn">LOGOUT</button></a>
  <div class="dropdown-content">
  </div>
</div>

	</TD>
	
	
</TR>

	</TABLE>
	</BODY>
</HTML>