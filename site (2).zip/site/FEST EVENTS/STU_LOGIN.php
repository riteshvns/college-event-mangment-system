
<?php
session_start();
include('connect.php');
if(isset($_POST['submit']))
{
	
		$mail_id=$_POST['mail_id'];
		$password=$_POST['password'];
		
		$qry="SELECT * FROM `reg_form` WHERE `mail_id`='$mail_id' AND `password`='$password'";
		$run=mysqli_query($con,$qry);
		
		$row=mysqli_num_rows($run);
		if($row<1)
		{?>
			<script>alert('username or password not match !!');
			window.open('STU_LOGIN.php','_self');
			</script>
			
			<?php
			
		}
		
		else
		{
			
						
			$data=mysqli_fetch_assoc($run);
			$_SESSION['stu_event']=$data['mail_id'];
			
			
			header('location:VIEW PROFILE.php');
		}
}
?>


<html>
<head>
<title> STUDENT login</title>

<link rel="stylesheet" type="text/css" href="css/csslogin.css">
<link rel="stylesheet" type="text/css" href="css/HOME.css">
</head>
<body>
<?php include 'HEADER.php'; ?>


<div class="aaa">
<div class="loginbox" >
<img src="img/login1.jpg" class="avatar" class="overlay">

<h1>STUDENT LOGIN</h1>
<form action="#" METHOD="POST">
<p>Username</p>
<input type="text" name="mail_id" placeholder="Enter Username" autofocus="autofocus" required="">
<p>Password</p>
<input type="password" name="password" placeholder="Enter Password" required="">
<a href="VIEW PROFILE.php"><input type="submit" name="submit" value="login"></a>
<a href="#">Don't have an Account?</a>
</form>
</div>
</div>

</body>
</html>