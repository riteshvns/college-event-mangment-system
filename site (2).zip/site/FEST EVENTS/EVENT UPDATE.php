
<?php
			session_start();
			if(isset($_SESSION['stu_event']))
			{ 
				$reg=$_SESSION['stu_event'];
			}
				else
			{
				header('location:login.php');
			}

			?>

<HTML>
<HEAD>
<TITLE>STUDENT REGISTRATION FORM</TITLE>
<STYLE>

BODY{

	background-size: COVER;
}

TD {

	PADDING: PX;
}

TD input[type="text"], input[type="password"]
{
border:none;
border-bottom:1px solid #fff;
background:transparent;
outline:none;
height:40px;
color:#fff;
font-size:16px;
}

</STYLE>

</HEAD>

<BODY BACKGROUND="img/22.JPG">
<?php include 'EDIT BY STUDENT.php';?>

<CENTER>
	
<B><U><FONT SIZE="5" COLOR="ORANGE">UPDATION FORM</FONT></U></B>

<TABLE>
<form action="#" method="POST" enctype="multipart/form-data">
<TABLE BORDER="0">

<?php

include 'connect.php';
$que = "select * from reg_form  where `mail_id`='$reg'";
$run = mysqli_query($con,$que);
$i=1;
while($row=mysqli_fetch_array($run))
{
$stu_name = $row['stu_name'];
$roll_no = $row['roll_no'];
$course = $row['course'];
$year = $row['year'];
$dob = $row['dob'];
$mob_no = $row['mob_no'];
$mail_id = $row['mail_id'];
$address = $row['address'];
$password = $row['password'];
$photo = $row['photo'];
    
?>

<TR>
	<TD><FONT SIZE="3" COLOR="WHITE">STUDENT'S NAME</FONT></TD>
<TD><input type="text" name="stu_name" value="<?php echo $stu_name; ?>" autofocus="autofocus" required=""  ></TD>



</TR>
<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">ROLL NUMBER</FONT></TD>
<TD><input type="text" name="roll_no" value="<?php echo $roll_no; ?>"  required=""></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">COURSE</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="course" value="<?php echo $course; ?>"  ></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">YEAR</FONT></TD>
<TD><SELECT name="year">
	<OPTION VALUE="1ST YEAR">1ST YEAR</OPTION>
	<OPTION VALUE="2ND YEAR">2ND YEAR</OPTION>
	<OPTION VALUE="3RD YEAR">3RD YEAR</OPTION>

</SELECT></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">D.O.B</FONT></TD>
<TD><INPUT TYPE="date" NAME="dob" value="<?php echo $dob; ?>"  ></TD>

</TR>

<TR>


	
<TD><FONT SIZE="3" COLOR="WHITE" >MOBILE No.</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="mob_no" value="<?php echo $mob_no; ?>"  ></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">MAIL</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="mail_id" value="<?php echo $mail_id; ?>"  readonly></TD>

</TR>


<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">ADDRESS</FONT></TD>
<TD><INPUT TYPE="TEXT" NAME="address" value="<?php echo $address; ?>"  ></TD>

</TR>

<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">PASSWORD</FONT></TD>
<TD><INPUT TYPE="PASSWORD" NAME="password" value="<?php echo $password; ?>"  ></TD>

</TR> 
<TR>
	
<TD><FONT SIZE="3" COLOR="WHITE">PHOTO</FONT></TD>
<TD><INPUT TYPE="FILE" NAME="photo"></TD>

</TR>
<TR>
	<TD COLSPAN="2" ALIGN="CENTER">
		<INPUT TYPE="SUBMIT" VALUE="UPDATE PROFILE" NAME="submit">
	</TD>
</TR>
<?php } 


include 'connect.php';

if(isset($_POST['submit'])){

$photo=$_FILES['photo']['name'];
$photo_tmp=$_FILES['photo']['tmp_name'];
move_uploaded_file($photo_tmp,"upload_images/$photo");

$stu_name = $_POST['stu_name'];
$roll_no = $_POST['roll_no'];
$course = $_POST['course'];
$year = $_POST['year'];
$dob = $_POST['dob'];
$mob_no = $_POST['mob_no'];

$address = $_POST['address'];
$password = $_POST['password'];


$query = mysqli_query($con,"UPDATE `reg_form` SET `stu_name`='$stu_name',`roll_no`='$roll_no',`course`='$course',`year`='$year',`dob`='$dob',`mob_no`='$mob_no',`mail_id`='$reg',`photo`='$photo',`address`='$address',`password`='$password' WHERE `mail_id`='$reg'");
if($query)
{
	echo"<script>alert('Profile Update  successfully')</script>";
	echo"<script>window.open('VIEW PROFILE.php','_self')</script>";
}
else{echo"<script>alert('Profile Update failed')</script>";}
} 
 ?>





	</TABLE>

</CENTER>
</BODY>
</HTML>
