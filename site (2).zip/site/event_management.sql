-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2022 at 06:12 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `username`, `password`) VALUES
(1, 'admin', '1111');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `eve_id` int(11) NOT NULL,
  `eve_name` varchar(50) NOT NULL,
  `st_dt` varchar(20) NOT NULL,
  `end_dt` varchar(20) NOT NULL,
  `num_part` varchar(4) NOT NULL,
  `descr` varchar(800) NOT NULL,
  `img` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`eve_id`, `eve_name`, `st_dt`, `end_dt`, `num_part`, `descr`, `img`) VALUES
(3, 'ADHARSHILA', '2022-07-03', '2022-07-06', '4', 'ADHARSHILA PROGRAMME', 'Adharshila-2011-Foundation-Day-at-SMS.jpg'),
(4, 'GROUP DANCE', '2022-07-04', '2022-07-08', '12', 'GROUP DANCE PROGRAMME', '11.png'),
(5, 'SOLO DANCE', '2022-07-05', '2022-07-07', '6', 'SOLO DANCE PERFORMANCE', '33.jpg'),
(6, 'SOLO SINGING', '2022-07-06', '2022-07-09', '6', 'SOLO SINGING PROGRAMME', '44.jpg'),
(7, 'GROUP SINGING', '2022-07-12', '2022-07-17', '14', 'GROUP SINGING PROGRAMME', '66.jpg'),
(8, 'RAMP WALK', '2022-07-08', '2022-07-11', '13', 'RAMP WALK PROGRAMME', 'Ramp Walk.webp'),
(9, 'CULTURAL PROGRAMME', '2022-07-13', '2022-07-15', '22', 'CULTURAL PROGRAMME\r\n', 'Cultural Events of School of Management Sciences Varanasi_Events.png'),
(10, 'DEBATE PROGRAMME', '2022-07-01', '2022-07-06', '7', 'DEBATE PROGRAMME HELD BY STUDENT OF School of Management Sciences', 'DBT.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `event_images`
--

CREATE TABLE `event_images` (
  `img_id` int(11) NOT NULL,
  `event_name` varchar(70) NOT NULL,
  `event_img` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_images`
--

INSERT INTO `event_images` (`img_id`, `event_name`, `event_img`) VALUES
(1, 'SDSDSF', '125.jpg'),
(2, 'wwww', 'A2.jpg'),
(3, 'ADHARSHILA', '11.png'),
(4, 'GROUP DANCE', '22.png'),
(5, 'SOLO DANCE', '33.jpg'),
(6, 'SOLO SINGING', '44.jpg'),
(7, 'GROUP SINGING', '66.jpg'),
(8, 'RAMP WALK', 'Ramp Walk.webp'),
(9, 'DEBATE PROGRAMME', 'DBT.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `join_event`
--

CREATE TABLE `join_event` (
  `join_id` int(11) NOT NULL,
  `mail_id` varchar(50) NOT NULL,
  `eve_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `join_event`
--

INSERT INTO `join_event` (`join_id`, `mail_id`, `eve_name`) VALUES
(5, 'dreamsofdp@gmail.com', 'DEBATE PROGRAMME'),
(6, 'dreamsofdp@gmail.com', 'SOLO SINGING');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `note_id` int(11) NOT NULL,
  `note_desc` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`note_id`, `note_desc`) VALUES
(6, 'SOLO SINGING EVENT IS ABOUT TO HELD IN JULY 2022'),
(7, 'GROUP SINGING EVENT IS ABOUT TO HELD IN JULY 2022'),
(8, 'SOLO DANCE EVENT IS ABOUT TO HELD IN JULY 2022'),
(9, 'GROUP DANCE EVENT IS ABOUT TO HELD IN JULY 2022'),
(10, 'DEBATE PROGRAMME IS ABOUT TO HELD IN JULY 2022'),
(11, 'RAMP WALK EVENT IS ABOUT TO HELD IN JULY 2022'),
(12, 'ADHARSHILA EVENT IS ABOUT TO HELD IN JULY 2022'),
(13, 'CULTURAL EVENT IS ABOUT TO HELD IN JULY 2022');

-- --------------------------------------------------------

--
-- Table structure for table `reg_form`
--

CREATE TABLE `reg_form` (
  `reg_id` int(11) NOT NULL,
  `stu_name` varchar(50) NOT NULL,
  `roll_no` varchar(30) NOT NULL,
  `course` varchar(40) NOT NULL,
  `year` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `mob_no` varchar(20) NOT NULL,
  `mail_id` varchar(50) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg_form`
--

INSERT INTO `reg_form` (`reg_id`, `stu_name`, `roll_no`, `course`, `year`, `dob`, `mob_no`, `mail_id`, `photo`, `address`, `password`) VALUES
(1, 'www', '1111', 'ggg', '1ST YEAR', '2022-07-03', '3333', '33333', '125.jpg', '33ghghgh', 'PAATHSHALA'),
(2, 'rrrr', '3333', 'ggg', '1ST YEAR', '2022-07-20', '3333', '333', '125.jpg', '33ghghgh', 'aaaaa'),
(3, 'SXDCDC', 'FGBGFNHG', '', '1ST YEAR', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `res_id` int(11) NOT NULL,
  `res_desc` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`res_id`, `res_desc`) VALUES
(1, 'qqqqqqq'),
(2, 'dfddf'),
(3, '222222'),
(4, 'vvvvvv');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`eve_id`);

--
-- Indexes for table `event_images`
--
ALTER TABLE `event_images`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `join_event`
--
ALTER TABLE `join_event`
  ADD PRIMARY KEY (`join_id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `reg_form`
--
ALTER TABLE `reg_form`
  ADD PRIMARY KEY (`reg_id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`res_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `eve_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `event_images`
--
ALTER TABLE `event_images`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `join_event`
--
ALTER TABLE `join_event`
  MODIFY `join_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `note_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `reg_form`
--
ALTER TABLE `reg_form`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `res_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
